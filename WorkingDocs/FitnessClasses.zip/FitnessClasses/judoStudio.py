class judoStudio:
	fitnessclass = 4
	def __init__(self, calories_burned=None, session_length=None,intensity=None)
	self.burned_calories = burned_calories
	self.session_length = session_length
	self.intensity = intensity





