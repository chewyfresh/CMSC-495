class hipHopYoga:
	fitnessclass = 6
	def __init__(self, burned_calories=None, session_length=None,intensity=None)
	self.burned_calories = burned_calories
	self.session_length = session_length
	self.intensity = intensity